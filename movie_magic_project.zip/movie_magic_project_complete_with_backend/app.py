
from flask import Flask, render_template, request, redirect, session, url_for
import uuid

app = Flask(__name__)
app.secret_key = "secret123"

users = []
bookings = []

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        for u in users:
            if u['email'] == email:
                return "User already exists. <a href='/login'>Login</a>"
        users.append({'name': name, 'email': email, 'password': password})
        return redirect("/login")
    return render_template("register.html")

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form['email']
        password = request.form['password']
        for u in users:
            if u['email'] == email and u['password'] == password:
                session['user'] = u['name']
                session['email'] = email
                return redirect("/dashboard")
        return "Invalid credentials. <a href='/login'>Try again</a>"
    return render_template("login.html")

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/login')
    return render_template("dashboard.html")

@app.route('/book', methods=["GET", "POST"])
def book():
    if 'user' not in session:
        return redirect('/login')
    if request.method == "POST":
        movie = request.form['movie']
        showtime = request.form['showtime']
        bookings.append({
            'id': str(uuid.uuid4()),
            'email': session['email'],
            'movie': movie,
            'showtime': showtime
        })
        return redirect("/confirmation")
    return render_template("booking.html")

@app.route('/confirmation')
def confirmation():
    if 'user' not in session:
        return redirect('/login')
    return render_template("confirmation.html")

@app.route('/mybookings')
def mybookings():
    if 'user' not in session:
        return redirect('/login')
    my = [b for b in bookings if b['email'] == session['email']]
    return render_template("bookings.html", bookings=my)

@app.route('/cancel/<booking_id>', methods=["POST"])
def cancel(booking_id):
    global bookings
    bookings = [b for b in bookings if b['id'] != booking_id]
    return redirect("/mybookings")

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
